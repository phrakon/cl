#ifndef SENDALERT_H
#define SENDALERT_H

using namespace std;

class CSendAlert
{
public:
    CSendAlert();
    ~CSendAlert();

    void Test(string message, string pKey);
};

#endif // SENDALERT_H
